async function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Validación básica con SweetAlert
    if (!username || !password) {
        Swal.fire({
            title: "Campos Incompletos",
            text: "Por favor, complete todos los campos",
            icon: "warning",
            button: "Entendido",
        });
        return;
    }

    try {
        // Mostrar loading mientras se procesa la petición
        Swal.fire({
            title: "Procesando",
            text: "Por favor espere...",
            icon: "info",
            buttons: false,
            closeOnClickOutside: false,
            closeOnEsc: false,
        });

        const response = await fetch('api/login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify({
                username: username,
                password: password
            })
        });

        const data = await response.json();

        if (data.success) {
            // Mensaje de éxito antes de redirigir
            Swal.fire({
                title: "¡Bienvenido!",
                text: "Inicio de sesión exitoso",
                icon: "success",
                button: false,
                timer: 1500,
            }).then(() => {
                window.location.href = data.redirect || 'dashboard.php';
            });
        } else {
            // Mensaje de error en las credenciales
            Swal.fire({
                title: "Error",
                text: data.error || "Credenciales inválidas",
                icon: "error",
                button: "Intentar nuevamente",
            });
        }
    } catch (error) {
        // Mensaje de error en la conexión
        Swal.fire({
            title: "Error de Conexión",
            text: "No se pudo conectar con el servidor",
            icon: "error",
            button: "Entendido",
        });
        console.error('Error:', error);
    }
}

// Añadimos evento para el Enter
document.addEventListener('keypress', function (e) {
    if (e.key === 'Enter' &&
        (document.activeElement.id === 'username' ||
            document.activeElement.id === 'password')) {
        // Efecto visual en el botón
        const loginButton = document.querySelector('.btn-login');
        loginButton.style.opacity = '0.8';
        setTimeout(() => {
            loginButton.style.opacity = '1';
            login();
        }, 100);
    }
});