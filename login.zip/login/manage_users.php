<?php

require_once 'middleware/auth.php';
require_once 'db.php';

// Verificamos que el usuario sea administrador
$user = checkAuth('admin');
if (!$user) {
    exit();
}

$db = new Database();
$conn = $db->connect();

// Modificamos la consulta para incluir el campo active
$stmt = $conn->prepare("SELECT id, username, role, active FROM users ORDER BY active DESC, username ASC");
$stmt->execute();
$users = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Obtenemos los roles disponibles
$stmt = $conn->prepare("SELECT role_name, permissions FROM roles");
$stmt->execute();
$roles = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Gestión de Usuarios</title>

    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th,
        .table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .table th {
            background-color: #f5f5f5;
        }

        .button {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-right: 5px;
        }

        .button-primary {
            background-color: #007bff;
            color: white;
        }

        .button-danger {
            background-color: #dc3545;
            color: white;
        }

        .button-warning {
            background-color: #ffc107;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            width: 70%;
            max-width: 500px;
            border-radius: 5px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .inactive-row {
            background-color: #f8f9fa;
            color: #6c757d;
        }

        .status-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.9em;
            display: inline-block;
            margin-left: 5px;
        }

        .status-badge.active {
            background-color: #28a745;
            color: white;
        }

        .status-badge.inactive {
            background-color: #dc3545;
            color: white;
        }

        .button-success {
            background-color: #28a745;
            color: white;
        }
    </style>

</head>

<body>
    <div class="container">
        <h1>Gestión de Usuarios</h1>
        <button onclick="window.location.href='dashboard.php'" class="button">
            Volver al Dashboard
        </button>
        <button onclick="showAddUserModal()" class="button button-primary">
            Añadir Usuario
        </button>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Rol</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr class="<?php echo isset($user['active']) && $user['active'] ? '' : 'inactive-row'; ?>">
                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo htmlspecialchars($user['role']); ?></td>
                        <td>
                            <span
                                class="status-badge <?php echo isset($user['active']) && $user['active'] ? 'active' : 'inactive'; ?>">
                                <?php echo isset($user['active']) && $user['active'] ? 'Activo' : 'Inactivo'; ?>
                            </span>
                        </td>
                        <td>
                            <button onclick="showEditUserModal(<?php echo htmlspecialchars(json_encode($user)); ?>)"
                                class="button button-warning">Editar</button>
                            <?php if (!isset($user['active']) || $user['active']): ?>
                                <button onclick="toggleUserStatus(<?php echo $user['id']; ?>, false)"
                                    class="button button-danger">Desactivar</button>
                            <?php else: ?>
                                <button onclick="toggleUserStatus(<?php echo $user['id']; ?>, true)"
                                    class="button button-success">Reactivar</button>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Modal para añadir/editar usuario -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <h2 id="modalTitle">Añadir Usuario</h2>
            <form id="userForm" onsubmit="saveUser(event)">
                <input type="hidden" id="userId">
                <div class="form-group">
                    <label for="username">Usuario:</label>
                    <input type="text" id="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" id="password">
                </div>
                <div class="form-group">
                    <label for="role">Rol:</label>
                    <select id="role" required>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?php echo htmlspecialchars($role['role_name']); ?>">
                                <?php echo htmlspecialchars($role['role_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="button button-primary">Guardar</button>
                <button type="button" onclick="closeModal()" class="button">Cancelar</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="js/manage_users.js"></script>
</body>

</html>