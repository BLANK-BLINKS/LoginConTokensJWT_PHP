<?php

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/vendor/autoload.php';

use \Firebase\JWT\JWT;
use \Firebase\JWT\Key;

class JWTHandler
{
    public static function generateToken($user_id, $username, $role)
    {
        $payload = [
            'user_id' => $user_id,
            'username' => $username,
            'role' => $role,
            'iat' => time(),
            'exp' => time() + SESSION_LIFETIME,
            'jti' => bin2hex(random_bytes(16)) // Identificador único del token
        ];
        return JWT::encode($payload, JWT_SECRET, 'HS256');
    }

    public static function validateToken($token)
    {
        try {
            // JWT::decode espera solo el token y un objeto Key
            return JWT::decode($token, new Key(JWT_SECRET, 'HS256'));
        } catch (Exception $e) {
            // Si hay cualquier error en la decodificación, retornamos false
            return false;
        }
    }
}