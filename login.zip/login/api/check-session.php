<?php
require_once '../jwt_handler.php';
header('Content-Type: application/json');

$token = $_COOKIE['jwt_token'] ?? null;

if (!$token) {
    echo json_encode(['timeRemaining' => 0]);
    exit();
}

try {
    $decoded = JWTHandler::validateToken($token);
    
    if ($decoded) {
        $timeRemaining = $decoded->exp - time();
        echo json_encode(['timeRemaining' => $timeRemaining]);
    } else {
        echo json_encode(['timeRemaining' => 0]);
    }
} catch (Exception $e) {
    echo json_encode(['timeRemaining' => 0]);
}