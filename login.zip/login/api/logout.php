<?php
// api/logout.php
header('Content-Type: application/json');

// Asegurarnos de eliminar la cookie correctamente desde el servidor
setcookie('jwt_token', '', [
    'expires' => time() - 3600, // Tiempo en el pasado
    'path' => '/',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Strict'
]);

// Limpiar la sesión PHP por si acaso
session_start();
session_destroy();

// Enviar respuesta
echo json_encode(['success' => true, 'message' => 'Sesión cerrada correctamente']);