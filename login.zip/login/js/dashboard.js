// Función para verificar el token y obtener el tiempo restante
async function checkSessionTime() {
    try {
        const response = await fetch('api/check-session.php');
        const data = await response.json();

        if (data.timeRemaining <= 300 && data.timeRemaining > 0) { // 5 minutos
            // Mostrar alerta con cuenta regresiva
            Swal.fire({
                title: "¡Atención!",
                text: `Tu sesión expirará en ${Math.ceil(data.timeRemaining / 60)} minutos. ¿Deseas extenderla?`,
                icon: "warning",
                buttons: ["Cerrar sesión", "Extender sesión"],
                dangerMode: true,
            }).then((willExtend) => {
                if (willExtend) {
                    extendSession();
                } else {
                    logout();
                }
            });
        } else if (data.timeRemaining <= 0) {
            // Sesión expirada
            Swal.fire({
                title: "Sesión Expirada",
                text: "Tu sesión ha expirado. Por favor, inicia sesión nuevamente.",
                icon: "error",
                button: "Entendido",
            }).then(() => {
                window.location.href = 'index.html';
            });
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Función para extender la sesión
async function extendSession() {
    try {
        const response = await fetch('api/extend-session.php');
        const data = await response.json();

        if (data.success) {
            Swal.fire({
                title: "¡Éxito!",
                text: "Tu sesión ha sido extendida.",
                icon: "success",
                timer: 2000,
                buttons: false
            });
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// Verificar la sesión cada minuto
setInterval(checkSessionTime, 60000);

// Verificar inmediatamente al cargar la página
document.addEventListener('DOMContentLoaded', checkSessionTime);

async function logout() {
    try {
        // 1. Llamar a un endpoint de backend para eliminar la cookie
        await fetch('api/logout.php', {
            method: 'POST',
            credentials: 'include' // Importante para incluir las cookies
        });

        // 2. Eliminar la cookie del lado del cliente también
        document.cookie = 'jwt_token=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT; Secure; SameSite=Strict';

        // 3. Redirigir al login
        window.location.href = 'index.html';
    } catch (error) {
        console.error('Error durante el logout:', error);
    }
}