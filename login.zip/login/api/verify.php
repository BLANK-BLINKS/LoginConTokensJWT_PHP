<?php
require_once '../jwt_handler.php';
header('Content-Type: application/json');

// Obtener el token de las cookies o del header Authorization
$token = null;
if (isset($_COOKIE['jwt_token'])) {
    $token = $_COOKIE['jwt_token'];
} else if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
    $token = str_replace('Bearer ', '', $_SERVER['HTTP_AUTHORIZATION']);
}

if (!$token) {
    echo json_encode(['valid' => false, 'message' => 'No token provided']);
    exit;
}

$decoded = JWTHandler::validateToken($token);
echo json_encode([
    'valid' => $decoded !== false,
    'payload' => $decoded ? (array)$decoded : null
]);