<?php
require_once __DIR__ . '/../jwt_handler.php';

function checkAuth($requiredRole = null)
{
    // Verificamos si existe el token
    $token = $_COOKIE['jwt_token'] ?? null;

    if (!$token) {
        // Si no hay token, redirigimos con un mensaje
        redirectToLogin("No se ha iniciado sesión");
        return false;
    }

    // Validamos el token
    $decoded = JWTHandler::validateToken($token);

    if (!$decoded) {
        // Si el token no es válido, redirigimos con un mensaje
        redirectToLogin("Sesión expirada o inválida");
        return false;
    }

    // Si se requiere un rol específico, lo verificamos
    if ($requiredRole && $decoded->role !== $requiredRole) {
        // Si no tiene el rol requerido, redirigimos con un mensaje
        redirectToLogin("No tienes permisos suficientes");
        return false;
    }

    return $decoded;
}

function redirectToLogin($message)
{
    // Guardamos el mensaje de error en una cookie temporal
    setcookie('auth_error', $message, [
        'expires' => time() + 5, // La cookie expira en 5 segundos
        'path' => '/',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);

    // Redirigimos al login
    header('Location: /login/index.html');
    exit();
}