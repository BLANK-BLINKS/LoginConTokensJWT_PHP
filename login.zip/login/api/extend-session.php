<?php
require_once '../jwt_handler.php';
require_once '../db.php';
header('Content-Type: application/json');

$token = $_COOKIE['jwt_token'] ?? null;

if (!$token) {
    echo json_encode(['success' => false, 'error' => 'No session found']);
    exit();
}

try {
    $decoded = JWTHandler::validateToken($token);
    
    if ($decoded) {
        // Generar nuevo token con tiempo extendido
        $newToken = JWTHandler::generateToken(
            $decoded->user_id,
            $decoded->username,
            $decoded->role
        );
        
        // Establecer nueva cookie
        setcookie('jwt_token', $newToken, [
            'expires' => time() + 120,
            'path' => '/',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Invalid token']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}