<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'login_db');
define('JWT_SECRET', 'qwerty33');
define('SESSION_LIFETIME', 120);