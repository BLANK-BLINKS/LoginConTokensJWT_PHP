<?php

require_once 'middleware/auth.php';
require_once 'db.php';

$user = checkAuth();
if (!$user) {
    header('Location: index.html');
    exit();
}

$db = new Database();
$conn = $db->connect();

// Mejoramos la obtención de permisos
$stmt = $conn->prepare("SELECT permissions FROM roles WHERE role_name = ?");
$stmt->bind_param("s", $user->role);
$stmt->execute();
$result = $stmt->get_result();
$roleData = $result->fetch_assoc();

// Decodificamos los permisos y verificamos que sea un array
$permissions = [];
if ($roleData && isset($roleData['permissions'])) {
    $permissions = json_decode($roleData['permissions'], true) ?? [];
}
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <style>
        .dashboard-container {
            padding: 20px;
        }

        .user-info {
            margin-bottom: 20px;
        }

        .action-buttons button {
            margin: 5px;
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .action-buttons button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        .content-area {
            margin-top: 20px;
            padding: 15px;
            border: 1px solid #ddd;
        }

        .logout-btn {
            float: right;
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>

<body>
    <div class="dashboard-container">
        <button onclick="logout()" class="logout-btn">Cerrar Sesión</button>

        <div class="user-info">
            <h1>Bienvenido <?php echo htmlspecialchars($user->username); ?></h1>
            <p>Rol: <?php echo htmlspecialchars($user->role); ?></p>
            <p>Permisos: <?php echo is_array($permissions) ? implode(", ", $permissions) : 'Sin permisos asignados'; ?>
            </p>
        </div>

        <div class="action-buttons">
            <button <?php echo !in_array('read', $permissions) ? 'disabled' : ''; ?>>
                Ver Contenido
            </button>
            <button <?php echo !in_array('write', $permissions) ? 'disabled' : ''; ?>>
                Crear Contenido
            </button>
            <button <?php echo !in_array('delete', $permissions) ? 'disabled' : ''; ?>>
                Eliminar Contenido
            </button>
            <?php if (in_array('manage_users', $permissions)): ?>
                <button onclick="window.location.href='manage_users.php'">
                    Gestionar Usuarios
                </button>
            <?php endif; ?>
        </div>

        <div class="content-area">
            <h3>Contenido del Dashboard</h3>
            <!-- Aquí puedes agregar más contenido específico según el rol -->
            <?php if ($user->role === 'admin'): ?>
                <div>Panel de Administración Completo</div>
            <?php elseif ($user->role === 'editor'): ?>
                <div>Panel de Editor - Gestión de Contenidos</div>
            <?php else: ?>
                <div>Panel de Usuario - Vista Limitada</div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="js/dashboard.js"></script>

</body>

</html>