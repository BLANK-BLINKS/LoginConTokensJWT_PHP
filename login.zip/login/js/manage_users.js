// Funciones del Modal
function showAddUserModal() {
    document.getElementById('modalTitle').textContent = 'Añadir Usuario';
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    document.getElementById('password').required = true;
    document.getElementById('userModal').style.display = 'block';
}

function showEditUserModal(user) {
    document.getElementById('modalTitle').textContent = 'Editar Usuario';
    document.getElementById('userId').value = user.id;
    document.getElementById('username').value = user.username;
    document.getElementById('role').value = user.role;
    document.getElementById('password').required = false;
    document.getElementById('userModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('userModal').style.display = 'none';
    document.getElementById('userForm').reset();
}

// Funciones de Gestión de Usuarios
async function toggleUserStatus(id, activate) {
    const action = activate ? 'reactivar' : 'desactivar';

    // Confirmación con SweetAlert
    const willToggle = await new Swal({
        title: `¿${action.charAt(0).toUpperCase() + action.slice(1)} usuario?`,
        text: `¿Estás seguro de que deseas ${action} este usuario?`,
        icon: "warning",
        buttons: ["Cancelar", "Sí"],
        dangerMode: !activate
    });

    if (!willToggle) return;

    try {
        // Mostrar loading
        Swal.fire({
            title: "Procesando",
            text: "Por favor espere...",
            icon: "info",
            buttons: false,
            closeOnClickOutside: false,
        });

        const response = await fetch('api/manage_users.php', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id: id,
                active: activate,
                action: 'toggle_status'
            })
        });

        if (response.ok) {
            await Swal.fire({
                title: "¡Éxito!",
                text: `Usuario ${action}do correctamente`,
                icon: "success",
                timer: 1500,
                buttons: false
            });
            location.reload();
        } else {
            const data = await response.json();
            Swal.fire({
                title: "Error",
                text: data.error || `Error al ${action} usuario`,
                icon: "error",
                button: "Entendido"
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            title: "Error",
            text: `Error al ${action} usuario: ${error.message}`,
            icon: "error",
            button: "Entendido"
        });
    }
}

async function saveUser(event) {
    event.preventDefault();
    const userId = document.getElementById('userId').value;
    const isNewUser = !userId;
    const userData = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        role: document.getElementById('role').value,
        active: true
    };

    try {
        // Mostrar loading
        Swal.fire({
            title: "Guardando",
            text: "Por favor espere...",
            icon: "info",
            buttons: false,
            closeOnClickOutside: false,
        });

        const response = await fetch('api/manage_users.php', {
            method: userId ? 'PUT' : 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ ...userData, id: userId })
        });

        if (response.ok) {
            await Swal.fire({
                title: "¡Éxito!",
                text: `Usuario ${isNewUser ? 'creado' : 'actualizado'} correctamente`,
                icon: "success",
                timer: 1500,
                buttons: false
            });
            closeModal();
            location.reload();
        } else {
            const data = await response.json();
            Swal.fire({
                title: "Error",
                text: data.error || 'Error al guardar usuario',
                icon: "error",
                button: "Entendido"
            });
        }
    } catch (error) {
        console.error('Error:', error);
        Swal.fire({
            title: "Error",
            text: `Error al guardar usuario: ${error.message}`,
            icon: "error",
            button: "Entendido"
        });
    }
}

// Función mejorada para cerrar modal
function closeModal() {
    const form = document.getElementById('userForm');
    if (form.dataset.hasChanges === 'true') {
        Swal.fire({
            title: "¿Estás seguro?",
            text: "Los cambios no guardados se perderán",
            icon: "warning",
            buttons: ["Cancelar", "Sí, salir"],
            dangerMode: true,
        }).then((willClose) => {
            if (willClose) {
                document.getElementById('userModal').style.display = 'none';
                form.reset();
                form.dataset.hasChanges = 'false';
            }
        });
    } else {
        document.getElementById('userModal').style.display = 'none';
        form.reset();
    }
}

// Detectar cambios en el formulario
document.getElementById('userForm').addEventListener('input', function () {
    this.dataset.hasChanges = 'true';
});