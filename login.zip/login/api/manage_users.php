<?php
require_once '../middleware/auth.php';
require_once '../db.php';

header('Content-Type: application/json');

// Verificar que sea administrador
$user = checkAuth('admin');
if (!$user) {
    http_response_code(403);
    echo json_encode(['error' => 'Acceso no autorizado']);
    exit();
}

$db = new Database();
$conn = $db->connect();

// Manejar diferentes métodos HTTP
switch ($_SERVER['REQUEST_METHOD']) {
    case 'POST': // Crear usuario
        $data = json_decode(file_get_contents('php://input'), true);

        // Validar datos requeridos
        if (!isset($data['username']) || !isset($data['password']) || !isset($data['role'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Datos incompletos']);
            exit();
        }

        // Hash de la contraseña
        $hash = password_hash($data['password'], PASSWORD_DEFAULT);

        // Insertar usuario (ahora incluimos el campo active)
        $stmt = $conn->prepare("INSERT INTO users (username, password, role, active) VALUES (?, ?, ?, 1)");
        $stmt->bind_param("sss", $data['username'], $hash, $data['role']);

        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'id' => $conn->insert_id]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Error al crear usuario']);
        }
        break;

    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);

        if (!isset($data['id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'ID no proporcionado']);
            exit();
        }

        // Si es una actualización de estado (activar/desactivar)
        if (isset($data['action']) && $data['action'] === 'toggle_status') {
            $active = $data['active'] ? 1 : 0;
            $stmt = $conn->prepare("UPDATE users SET active = ? WHERE id = ?");
            $stmt->bind_param("ii", $active, $data['id']);
        }
        // Si es una actualización normal de usuario
        else {
            if (!empty($data['password'])) {
                $hash = password_hash($data['password'], PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?");
                $stmt->bind_param("sssi", $data['username'], $hash, $data['role'], $data['id']);
            } else {
                $stmt = $conn->prepare("UPDATE users SET username = ?, role = ? WHERE id = ?");
                $stmt->bind_param("ssi", $data['username'], $data['role'], $data['id']);
            }
        }

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Error al actualizar usuario']);
        }
        break;

    case 'DELETE':
        http_response_code(405);
        echo json_encode(['error' => 'Método no permitido']);
        break;
}