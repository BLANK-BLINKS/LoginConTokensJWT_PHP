<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

// Para debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Obtenemos y decodificamos los datos enviados
    $json = file_get_contents('php://input');
    if (!$json) {
        throw new Exception('No se recibieron datos');
    }

    $data = json_decode($json, true);
    if (!$data) {
        throw new Exception('Error al decodificar JSON');
    }

    // Validamos que existan los campos requeridos
    if (!isset($data['username']) || !isset($data['password'])) {
        throw new Exception('Faltan campos requeridos');
    }

    $username = $data['username'];
    $password = $data['password'];

    // Conectamos a la base de datos
    $conn = new mysqli('localhost', 'root', '', 'login_db');
    if ($conn->connect_error) {
        throw new Exception('Error de conexión: ' . $conn->connect_error);
    }

    // Consultamos el usuario
    $stmt = $conn->prepare("SELECT id, password, role, active FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // Verificamos credenciales
    if ($user && $user['active'] == 1 && password_verify($password, $user['password'])) {
        // Generamos el token JWT
        require_once '../jwt_handler.php';
        $token = JWTHandler::generateToken($user['id'], $username, $user['role']);

        // Establecemos la cookie
        setcookie('jwt_token', $token, [
            'expires' => time() + 120,
            'path' => '/',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Strict'
        ]);

        // Enviamos respuesta exitosa
        echo json_encode([
            'success' => true,
            'role' => $user['role'],
            'redirect' => 'dashboard.php'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'error' => 'Credenciales inválidas o usuario inactivo'
        ]);
    }

} catch (Exception $e) {
    // Manejamos cualquier error que ocurra
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}