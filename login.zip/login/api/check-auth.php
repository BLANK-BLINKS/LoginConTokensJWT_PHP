<?php

header('Content-Type: application/json');
require_once '../jwt_handler.php';
require_once 'config.php';

$token = $_COOKIE['jwt_token'] ?? null;
echo json_encode([
    'isAuthenticated' => $token ? true : false,
    'tokenInfo' => JWTHandler::validateToken($token)
]);